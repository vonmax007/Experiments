#pragma once
#include "StdAfx.h"

class ExperimentExecutor
{
public:
	ExperimentExecutor(void);
	~ExperimentExecutor(void);
	void exec();

};
